<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>


<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                Aspernatur iure laborum at molestias voluptatum reiciendis soluta,
                alias ipsum illum et dicta aut, tenetur maiores facere eveniet veritatis nihil enim. Error!</p>

        </div>
    </div>
    <?= $this->endSection(); ?>